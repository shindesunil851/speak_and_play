#ifndef GLOBAL
#define GLOBAL
namespace guicpp {

	extern long double tdistance;
		extern long double tokhura[];
	extern long double alpha[85][5];
	 extern long double updatedA[5][5],updatedB[5][32],updatedPi[5];
	extern long double sigma[84][5][5],gamma[85][5];
	extern long double data,pi[5],A[5][5],B[5][32];
	extern long double delta[85][5];
	extern long double beta[85][5];
	extern int psi[85][5],q[85];
    //vector<extern long double> d;


}

#endif