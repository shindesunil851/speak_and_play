//#include "stdAfx.h"
//#ifndef MyForm
//#define MyForm
#include <iomanip>
#include <sstream>
#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include <stdlib.h>
#include<math.h>
#include <algorithm> 

#include "global.h"
#include "newForm1.h"
#include "newForm2.h"
#include "newForm3.h"
#include "newForm4.h"
#include "global.h"
#include<Windows.h>
#include<MMSystem.h>
using namespace std;
#pragma once



namespace guicpp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	
	#define N 5
#define M 85

long double tdistance=0;
long double threshold;
long double tokhura[] = {1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};
long double alpha[85][5];
long double updatedA[5][5],updatedB[5][32],updatedPi[5];
long double sigma[84][5][5],gamma[85][5];
long double data,pi[5],A[5][5],B[5][32];
long double delta[85][5];
long double beta[85][5];
int psi[85][5],q[85];
string lang[]={"Hindi","English","Marathi"};
vector<long double> d;

//--------------------------------------------------------------Normalizing the recorded data--------------------------------------------
void normalization(vector<long double> &a,int s)
{
  long double max,min;
  max=*max_element(a.begin()+s, a.begin()+(s+320));
  min=*min_element(a.begin()+s, a.begin()+(s+320));
  if(abs(max)>abs(min))
  {
	  for(int i=s;i<s+320;i++)
	  a[i]=(a[i]/max)*5000;
  }
  else
   {
     for(int i=s;i<s+320;i++)
	    a[i]=(a[i]/abs(min))*5000;

   }
 // cout<<"Normalization Done\n";
}


//---------------------------------------------------------------DC SHIFT----------------------------------------------------

void DC_Shift(vector<long double> &a,int s)
{
	//cout<<"dc ";
    long double sum=0,i;
	for(i=0;i<500;i++)
	sum+=a[i];
	sum/=500;
	for(i=s;i<s+320;i++)
	{
		a[i]-=sum;
	}
	//cout<<"DC Shift Done\n";
}

//--------------------------------------------------------Applying Hamming Window------------------------------------------------

void HammingWindow(vector<long double> &a,int s)
{
	//cout<<"Hm ";
	long double data;
	vector<long double> hw;
	ifstream h;
	h.open("Hamming_window.txt");
	if(h.fail())
	{
	 cout<<"Unable to open the file";
	 exit(0);
	}
	else
	{
			while(h>>data)
				{
					 hw.push_back(data);
				}
	}
	int j=0;
	for(int i=s;i<(s+320);i++)
	{
		a[i]=a[i]*hw[j++];
	}
}

long double getDistance(long double cep[],vector <long double> arr)
{
	long double w[12]={1.0,3.0,7.0,13.0,19.0,22.0,25.0,33.0,42.0,50.0,56.0,61.0};
	long double temp=0,minimum=10000000;

	for(int m=0;m<5;m++)
	{
	for(int i=1;i<=12;i++)
	{
		temp+=(cep[i-1]-arr[m*12+i-1])*(cep[i-1]-arr[m*12+i-1])*w[i-1];
	}
	if(temp<minimum)
		minimum=temp;
	}
	return minimum/12;

}
//--------------------------Calculates ZCR of the recorded data-------------------------

long double ZCR(vector<long double> &a,int s,int e)
{
 long double count=0;
 while(s<e)
  {
   if(a[s]*a[s+1]<=0)
    {
	count++;
    }
	s++;
  }

return count;
}


//-------------------------------------------Calculating STE for each frames of 100 samples---------------------------------------------

long double STE(vector<long double>&a,int s,int e)
 {
	 
int count=e-s+1;
	long double energy=0;
	while(s<=e)
	{
		energy+=a[s]*a[s];
		s++;

	}
	energy=energy/count;

	return energy;

 }

//-----------------------------------------------------------Classification--------------------------------------------

int FindCluster(vector<vector<long double>> &val,vector<long double> &sm,int m) 
	{
	   long double tokhura[] = {1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};
	   long double limit=1000000;
	   int min=0;
	   for(int i=0;i<m;i++)
	   {

		   long double s=0;
		   int m=0;
		   	   for(int j=0;j<12;j++)
			   {
			       s+=(val[i][j]-sm[j])*(val[i][j]-sm[j])*tokhura[j];
				   m++;
			   }
			if(s<limit)
			{
			 min=i;
			 limit=s;
			}
			
	   }
	   tdistance = tdistance+limit;
	   return min;

	}

//-------------------------------------------------------------Updating CodeVector---------------------------------------------- 

void getCentroid(vector<long double> &result,vector<long double> &prev)
{
	
	if(result.size()==0)
		return;
	prev.clear();
	long double sum=0;int m=0;
	for(int k=0;k<12;k++)
	{
			sum=0;m=0;
	 for(int i=k;i<result.size();i+=12)
	   {
	    sum+=result[i];
	     m++;
	   } 
	 
	 prev.push_back(sum/m);
	}


}

//------------------------------------------------------Adding CodeVector to corresponding cluster--------------------------------

void addVector(vector<long double>&result,vector<long double>&sum)
{
	for(int i=0;i<12;i++)
	{
		result.push_back(sum[i]);
	}
}

//------------------------------------------------------------------LBG-------------------------------------------------

void lbg(vector<vector<long double>>&universe,vector<vector<long double>>&val,int m1)
{       
		vector<vector<long double>> result;
		result.resize(m1);
		int m=0;
		long double distortion_p=0,distortion_n=0;
	do{
		tdistance=0;
		distortion_p=distortion_n;
		int count=universe.size();
		cout<<"\n\n";

		cout<<"----------------------   "<<"ClusterSize->    "<<m1<<"    ------------------    Iteration->"<<m+1<<"     ------------------------\n\n\n";

		for(int i=0;i<count;i++)
		{
		   int index= FindCluster(val,universe[i],m1);
           addVector(result[index],universe[i]);        
		}

		long double z=0;
		distortion_n=tdistance/count;

		for(int i=0;i<m1;i++)
		{
			getCentroid(result[i],val[i]); //Updating Centroid
		}

		for(int i=0;i<m1;i++)
		{
			for(int j=0;j<12;j++)
			{
			cout<<val[i][j]<<" ";
			}
			cout<<"\n";
		}
		cout<<"\n\n\n";
		m++;

		for(int i=0;i<m1;i++)
			{
				result[i].clear();
			}

	}while(abs(distortion_p-distortion_n)>0.1); // Kmeans Termination
	
	cout<<"Size:-> "<<m1<<"  Distortion:->"<<distortion_n<<"\n\n";
	d.push_back(distortion_n);

	for(int i=0;i<m1;i++)
				{
					for(int j=0;j<12;j++)
					{
						cout<<val[i][j]<<" ";
					}
					cout<<endl;
				}

	cout<<"\n\n\n";
				
				
}

//-----------------------------------------------------Computes Average of the Universe and stores it into a new vector-------------------------------------------- 

void computeAvg(vector<vector<long double>>&smp,vector<long double>&codeBook )
 {
	 codeBook.clear();

	 long double sum=0;
	 for(int k=0;k<12;k++)
	 {
		for(int i=0;i<smp.size();i++)
	    {
			sum+=smp[i][k];
		}

	  	codeBook.push_back(sum/smp.size());
	 }

 }

//-------------------------------------------------Splitting the CodeVector by using splitting parameter----------------------------------------------

void splitCluster(vector<vector<long double>>&codeBook,int m)
{
	vector<vector<long double>> copy;
	copy.resize(m);

	for(int i=0;i<m;i++)
	{
		for(int j=0;j<12;j++)
		{
			copy[i].push_back(codeBook[i][j]);
		}
	}

	codeBook.clear();
	codeBook.resize(2*m);

	for(int i=0;i<m;i++)
	{
		// Two vector for storing the two spilt clusters

	   vector<long double> temp1,temp2;

	   for(int k=0;k<12;k++)
	   {
		   temp1.push_back(copy[i][k]+0.03*copy[i][k]);
		   temp2.push_back(copy[i][k]-0.03*copy[i][k]);
       }

	   for(int k=0;k<12;k++)
		{
		   codeBook[i].push_back(temp1[k]);
		   codeBook[i+m].push_back(temp2[k]);
	    }

	}
}
int maximum(vector<long double> &a)
{
	long double max,min;

	max=*max_element(a.begin(),a.end());
	min=*min_element(a.begin(),a.end());

	long double key;
	if(abs(max)>abs(min))
	{
		key=max;	
	}
	else 
		key=min;
	//cout<<key<<" ";
	for (int i = 0; i < a.size(); i++)
	{
		if (a[i] == max) 
		{
			//cout<<"Element present at index "<< i<<endl;
			return i;
		}
	}	
}	
int getMax(vector<long double>&arr)
{
	  long double pmax=arr[0],nmax=arr[0];
	  int p=0,n=0;
	  for(int i=1;i<arr.size();i++)
	  {
	  if(pmax<arr[i])
	    {
			pmax=arr[i];
			p=i;
	    }
	  if(nmax>arr[i])
	    {
			nmax=arr[i];
			n=i;
	    }
	  }
	  if(pmax<abs(nmax))
	   {
	    return n;
	   }
	  return p;
}
//------------------------------------------Computes Observation Sequence for each utterance of a digit using codebook---------------------------------------

int compute_Observation_Sequence(vector<vector<long double>>codebook,vector<long double>observation_universe)
{
	//cout<<"obs "; 
	long double distance[32],p=0,sum=0;
	for(int m=0;m<32;m++)
	{
		distance[m]=0;
	}

	for(int i=0;i<32;i++)
	{
		for(int j=0;j<12;j++)
		{
				distance[i]+=(codebook[i][j]-observation_universe[j])*(codebook[i][j]-observation_universe[j])*tokhura[j];
		}
		distance[i]=distance[i]/12;
	//	cout<<distance[i]<<endl;
  
	}	
	int index=0;
	sum=distance[0];

	for(int i=1;i<32;i++)
	{
		if(sum>distance[i])
		{
			sum=distance[i];
			index=i;
		}
	}
	return index;
}

 void durbin(vector<long double>&arr,int s,long double *r,long double *ai,long double *c)
 {
	int j=0;
	//normalization(arr,s);
	//DC_Shift(arr,s);
	//HammingWindow(arr,s);
	for(int i=0; i<13; i++)
		r[i] = 0;
    for(int i=0;i<13;i++)
    {
        for(int m=s;m<=(s+(320-1-i));m++)
        {
			if(m+i<arr.size())
            r[i] = r[i] + arr[m]*arr[m+i];

        }
    }

	
    //-------------------------------------------Calculating ai's-------------------------------------------

	int p=12;
    long double e[13],k[13],ar[13][13],sum;
    e[0]=r[0];
    for(int i=1;i<=p;i++)
    {
        sum=0;
        for(int j=1;j<=i-1;j++)
            sum = sum+(ar[i-1][j]*r[i-j]);

        if(i==1) sum=0;

        k[i]= (r[i]-sum)/e[i-1];
        ar[i][i]=k[i];

        for(int j=1;j<=i-1;j++)
        {
            ar[i][j]=ar[i-1][j] - (k[i]*ar[i-1][i-j]);
        }

        e[i]= (1-(k[i]*k[i]))*e[i-1];
    }
    for(int i=1;i<=p+1;i++)
    {
        ai[i]=ar[p][i];
    }
	
	
//-----------------------------------------------Calculating Ci's----------------------------------------------

	for(int i=1;i<=p;i++)
	{
		c[i]=ai[i];
	   	for(int j=1;j<i; j++)
		{
		    c[i] += (((long double)(j))/(i)) * c[j] * ai[i-j];
		}
	}


  std::fstream file;

  file.open ("testing1.txt", std::fstream::in | std::fstream::out | std::fstream::app);
  //use universe.txt for creating the universe using the data i.e. digits

  for(int i=1;i<13;i++)
  {
	  file<<c[i]<<endl;
  }

  file.close();

  //cout<<"durbin done ";

 }
 
 void durbin1(vector<long double>&arr,int s,long double *r,long double *ai,long double *c)
 {
	int j=0;
	//normalization(arr,s);
	//DC_Shift(arr,s);
	//HammingWindow(arr,s);
	for(int i=0; i<13; i++)
		r[i] = 0;
    for(int i=0;i<13;i++)
    {
        for(int m=s;m<=(s+(320-1-i));m++)
        {
			if(m+i<arr.size())
            r[i] = r[i] + arr[m]*arr[m+i];

        }
    }

	
    //------------------------------------------Calculating ai's------------------------------------------

	int p=12;
    long double e[13],k[13],ar[13][13],sum;
    e[0]=r[0];
    for(int i=1;i<=p;i++)
    {
        sum=0;
        for(int j=1;j<=i-1;j++)
            sum = sum+(ar[i-1][j]*r[i-j]);

        if(i==1) sum=0;

        k[i]= (r[i]-sum)/e[i-1];
        ar[i][i]=k[i];

        for(int j=1;j<=i-1;j++)
        {
            ar[i][j]=ar[i-1][j] - (k[i]*ar[i-1][i-j]);
        }

        e[i]= (1-(k[i]*k[i]))*e[i-1];
    }
    for(int i=1;i<=p+1;i++)
    {
        ai[i]=ar[p][i];
    }
	
	
//-----------------------------------------Calculating Ci's----------------------------------------------

	for(int i=1;i<=p;i++)
	{
		c[i]=ai[i];
	   	for(int j=1;j<i; j++)
		{
		    c[i] += (((long double)(j))/(i)) * c[j] * ai[i-j];
		}
	}


  std::fstream file;

  file.open ("testing1.txt", std::fstream::in | std::fstream::out | std::fstream::app);
  //use universe.txt for creating the universe using the data i.e. digits
  for(int i=1;i<13;i++)
	  file<<c[i]<<endl;

  file.close();

  //cout<<"durbin done ";

 }

 //---------------------------------------------Using for applying the threshold in Matrix B calculation----------------------------

long double power(long double x,long double p)
{
	long double result,i;
	result = 1;
	for(i = 0; i < p; i++)
		{
		 result=(long double)x*result;
		}
	return result;
}	

void alpha_Initialization(int observation[85],long double alpha[85][5],long double pi[5],long double B[5][32])
{
	for(int i=0;i<5;i++)
	{
	 alpha[0][i]=pi[i]*B[i][observation[0]];
	}
}
void alpha_Induction(int observation[85],long double alpha[85][5],long double A[5][5],long double B[5][32])
{
	for(int t=0;t<84;t++)
	{
	    for(int j=0;j<5;j++)
		{
		long double tot=0;
			for(int i=0;i<5;i++)
			{
				//prob. of partial sequence o1,o2,...ot until time t and  state Si at time t given model
				tot=tot+alpha[t][i]*A[i][j];      
			}
			alpha[t+1][j]=tot*B[j][observation[t+1]];
		}
	}
}

long double termination(long double alpha[85][5])
{
	long double probability=0;

	for(int i=0;i<5;i++)
	{
		probability=probability+alpha[84][i];		     //total probability
	}
	return probability;
}

void sigma_Compute(int observation[85],long double alpha[85][5],long double beta[85][5],long double A[5][5],long double B[5][32],long double p,long double sigma[84][5][5])
{
	for(int t=0;t<84;t++)
	{
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
			  //prob. of being in state i at time t and state j in time t+1 given model and the obs. sequence
	          sigma[t][i][j]=(alpha[t][i]*A[i][j]*B[j][observation[t+1]]*beta[t+1][j])/p;      
		    }																					
		}
	}
}

void gamma_Compute(long double sigma[84][5][5],long double alpha[85][5],long double p,long double gamma[85][5])
{
	for(int t=0;t<84;t++)
	{
		for(int i=0;i<5;i++)
		{
			long double temp=0;
			for(int j=0;j<5;j++)
			{
				 // prob. of obs. sequence ending in state Si at time t given Obs. and Lambda
				temp+=sigma[t][i][j];                        
			}                                                
			gamma[t][i]=temp;
		}
	}
			for(int i=0;i<5;i++)
			{
				gamma[84][i]=alpha[84][i]/p;
			}
}

void beta_Initialization(long double beta[85][5])
{
	for(int i=0;i<5;i++)
		beta[84][i]=1;
}

void beta_Induction(int observation[85],long double beta[85][5],long double A[5][5],long double B[5][32])
{
	for(int t=83;t>=0;t--)
	{
		for(int i=0;i<5;i++)
		{ 
			long double temp=0;
			int j;
			for(j=0;j<5;j++)
			{
				// prob. of Obs from t+1 to T given state is Si
				temp+=A[i][j]*B[j][observation[t+1]]*beta[t+1][j];      
			}
			beta[t][i]=temp;
		}
	}
	/*
	for(int i=0;i<5;i++)
	{
		int count=0,maxindex=0;
		long double sub=0;
		for(int j=0;j<32;j++)
			{
				if(computeB[i][j]<thr)
				{
					sub+=(threshold-computeB[i][j]);
					 computeB[i][j]=threshold;
					 count++;
				}
		
				if(computeB[i][j]>computeB[i][maxindex])
				{
					maxindex=j;
				}
			}
		
		computeB[i][maxindex]-=count*threshold;
	}*/
}

void beta_final(long double beta[85][5])
{
	long double temp=0;
	for(int i=0;i<5;i++)
	{
		cout<<beta[0][i]<<endl;
		temp+=beta[0][i];
	}
	cout<<temp<<" "<<endl;
}

void delta_Initialization(int observation[85],long double delta[85][5],int psi[85][5],long double pi[5],long double B[5][32])
{
	for(int i=0;i<5;i++)
	{
	 delta[0][i]=pi[i]*B[i][observation[0]];       
	 psi[0][i]=0;
	}
}

void delta_Recursion(int observation[85],long double delta[85][5],int psi[85][5],long double A[5][5],long double B[5][32])
{
	for(int t=1;t<85;t++)
	{
		for(int j=0;j<5;j++)
		{
			long double temp=0,max=0;
			int s=0; //State
			for(int i=0;i<5;i++)
			{
				temp=delta[t-1][i]*A[i][j];
				if(max<temp)
				{
					max=temp;
					s=i;
				}
			}
			delta[t][j]=max*B[j][observation[t]];
			psi[t][j]=s;
		}
	}
		//cout<<"-----------------------------delta--------------------------------------------------"<<endl;
/*	for(int t=0;t<85;t++)
	{
		for(int i=0;i<5;i++)
		{
			cout<<delta[t][i]<<" ";
		}
		cout<<endl;
	}
	cout<<"\n\n";
		cout<<"-----------------------------psi--------------------------------------------------"<<endl;	
	for(int t=0;t<85;t++)
	{
		for(int i=0;i<5;i++)
		{
			cout<<psi[t][i]+1<<" ";
		}
		cout<<endl;
	}
	cout<<"\n\n";*/
}

void delta_Terminate(long double delta[85][5],int psi[85][5],int q[85])
{
	long double p=0;
	int s=0; 
	for(int i=0;i<5;i++)

	{
	 // cout<<"Probability at T is "<<delta[84][i]<<endl;
			if(p<delta[84][i])
			{
				 // Finding value of i(state) for which the probability is max
				p=delta[84][i];
				s=i;            
			}
	}
	//cout<<endl;
	q[84]=s;
	int t=83; // T-1,T-2,T-3...2,1
	while(t>=0)
	{
		q[t]=psi[t+1][q[t+1]];
		t--;
	}
	//cout<<"Maximum Probability of Sequence is "<<p<<endl;
}

void StateSequence(int q[85])
{
	for(int i=0;i<85;i++)
	{
		cout<<"Time- "<<i+1<<"   State is "<<q[i]+1<<endl;
	}
	cout<<endl;
}

//-----------------------------------Updating the values of Matrix A using Solution to Problem 3 (Expectation Modification Procedure)-----------------------------

void updateA(long double sigma[84][5][5],long double gamma[85][5],long double updatedA[5][5])
{
	for(int i=0;i<5;i++)
	{
		long double temp=0;
		for(int t=0;t<84;t++)
			{
				//Expected #trans. from state Si  
				temp+=gamma[t][i];			
	     	}

		for(int j=0;j<5;j++)
		{
			long double temp1=0;
			for(int t=0;t<84;t++)
			{
				//Expected #trans. from state Si to state Sj
				temp1+=sigma[t][i][j];			 
			}
			updatedA[i][j]=temp1/temp;
		}
	}
}

//-----------------------------------Updating the values of Matrix B using Solution to Problem 3 (Expectation Modification Procedure)-----------------------------

void updateB(int observation[85],long double gamma[85][5],long double B[5][32],long double updatedB[5][32])
{
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<32;j++)
		{
		long double temp1=0,temp2=0;
		for(int t=0;t<85;t++)
			{
				temp1=temp1+gamma[t][i];         //Expected #times in state Sj
				if(observation[t]==j)
				temp2=temp2+gamma[t][i];		 //Expected #times in from state Sj and Observing symbol Vk
	     	}
			updatedB[i][j]=temp2/temp1;
		}
	}
	for(int i=0;i<5;i++)
	{
		int count=0,maxindex=0;
		long double sub=0;
		for(int j=0;j<32;j++)
			{
				if(updatedB[i][j]<threshold)
				{
					sub+=(threshold-updatedB[i][j]);
					 updatedB[i][j]=threshold;
					 count++;
				}
		
				if(updatedB[i][j]>updatedB[i][maxindex])
				{
					maxindex=j;
				}
			}
		
		updatedB[i][maxindex]-=count*threshold;
	}

}

//-----------------------------------Updating the values of Matrix pi using Solution to Problem 3 (Expectation Modification Procedure)-----------------------------

void updatePi(long double gamma[85][5],long double updatedPi[84])
{
	for(int i=0;i<5;i++)
	{
		updatedPi[i]=gamma[0][i];
	}
}

//--------------------------------------Use Forward Procedure to find the probability of the observation sequence given a model----------------------

int digitRecognizer(vector<long double> &obs)
{
		threshold= power(0.1,30);
		int observation[85];
	
		for(int i=0;i<85;i++)
			observation[i]=obs[i];

		long double pmax=0;
		int digit=0;
		for(int i=0;i<3;i++)
		{

			ifstream f;
			string path="Lang/model_";

			stringstream digitNo;  
			digitNo<<i;  
			string s1;  
		    digitNo>>s1;
			path+=s1;
	        path+=".txt";
	    	f.open(path);

			vector<long double> train;
			train.clear();

			long double data;
			while(f>>data)
			{
				train.push_back(data);
			}
			
			for(int i=0;i<5;i++)
			{
				pi[i]=train[i];
			}
			
			for(int i=0;i<5;i++)
			{
			 for(int j=0;j<5;j++)
			 	 {
					A[i][j]=train[5+i*5+j];
				 }
			}

			for(int i=0;i<5;i++)
			{
			 for(int j=0;j<32;j++)
				{
					B[i][j]=train[30+i*32+j];		
				}
			}
			
			long double alpha[85][5];

			//----------------- Forward Procedure to calculate the Probability----------------------------

			alpha_Initialization(observation,alpha,pi,B);
			alpha_Induction(observation,alpha,A,B);
			long double probability= termination(alpha);
			
				if(pmax<=probability)
				{
				   pmax=probability;
				   digit=i;
				}

	}

	return digit;
 }

//----------------------------------Creating and Storing the updated model in new files(Average)------------------------------
void createNewmodel(int start)
{
		vector<long double>v[20],val;
		for(int end=1;end<21;end++)
		{
				ifstream inp;

				string path="newLang/model_";

				stringstream digit,utter;  
				digit<<start;  
				string s1,s2;  
				digit>>s1;
				path+=s1;
				path+="_";
				utter<<end;
				utter>>s2;
				path+=s2;
				path+=".txt";
				//cout<<path<<endl;
	    		inp.open(path);
				long double data;

				while(inp>>data)
					{
						v[end-1].push_back(data);
					}
		}

		for(int i=0;i<v[0].size();i++)
		{
		  long double temp=0; 

		  for(int j=0;j<20;j++)
		  {
				temp=temp+v[j][i];
		  }
		  val.push_back(temp/20);
		}

			ofstream mod;
			string path="Lang/model_";

			stringstream digit;  
			digit<<start;  
			string s1;  
		    digit>>s1;
			path+=s1;
	        path+=".txt";
	    	mod.open(path);

			for(int i=0;i<5;i++)
			{
				mod<<val[i]<<" ";
			}
			mod<<endl;

			for(int i=0;i<5;i++)
			{
				for(int	j=0;j<5;j++)
				{
					mod<<val[5+i*5+j]<<" ";
				}
			    mod<<endl;
			}
			for(int i=0;i<5;i++)
			{
			 for(int	j=0;j<32;j++)
				{
					mod<<val[30+i*32+j]<<" ";
				}
			 mod<<endl;
			}
}

//---------------------------------------------------------Updating the model using HMM----------------------------------
void hmm(vector<long double> &obs,int start,int end)
{
	threshold= power(0.1,30);

	int observation[85];
	for(int i=0;i<85;i++)
	{
		observation[i]=obs[i];
	}
		

		ifstream inp;

		string path="Lang/model_";

			stringstream digit;  
			digit<<start;  
			string s1;  
		    digit>>s1;
			path+=s1;
	        path+=".txt";

		inp.open(path);
		
		vector<long double> train;

		while(inp>>data)
		{
			train.push_back(data);
	    }
		inp.close();

		for(int i=0;i<5;i++)
			{
				pi[i]=train[i];
		   }

		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
				A[i][j]=train[5+i*5+j];
			}
		}

		for(int i=0;i<5;i++)
		{
			for(int j=0;j<32;j++)
			{
				B[i][j]=train[30+i*32+j];
			}
		}


   
	for(int k=0;k<20;k++)
	{
		//---------------------------Forward Procedure---------------------------	
		 alpha_Initialization(observation,alpha,pi,B);
		 alpha_Induction(observation,alpha,A,B);
		
		 long double probability= termination(alpha);

		//--------------------------Backward Procedure--------------------------
		 beta_Initialization(beta);
		 beta_Induction(observation,beta,A,B);

		//--------------------------Viterbi-------------------------------------
		 sigma_Compute(observation,alpha,beta,A,B,probability,sigma);
		 gamma_Compute(sigma,alpha,probability,gamma);

		 delta_Initialization(observation,delta,psi,pi,B);
		 delta_Recursion(observation,delta,psi,A,B);
		 delta_Terminate(delta,psi,q);

		 //------------------------------Expactation Modification-----------------
		 updatePi(gamma,updatedPi);
		 updateA(sigma,gamma,updatedA);
		 updateB(observation,gamma,B,updatedB);


	   //------------------------Updating value of Matrix A for next Iteration---------------------------
	   for(int i=0;i<5;i++)
		 {
			for(int j=0;j<5;j++)
			{
				A[i][j]=updatedA[i][j];
			}
		 }
		 //------------------------Updating value of Matrix B for next Iteration---------------------------
		 for(int i=0;i<5;i++)
		 {
			for(int j=0;j<32;j++)
			{
				B[i][j]=updatedB[i][j];
			}
		 }
		 //------------------------Updating value of Pi for next Iteration---------------------------
		 for(int i=0;i<5;i++)
		 {
			pi[i]=updatedPi[i];
		 }

		 string path1="newLang/model_";

			stringstream digit,utter;  
			digit<<start;  
			string s1,m1;  
		    digit>>s1;
			path1+=s1;
			utter<<end;
			utter>>m1;
			path1+="_";
			path1+=m1;
			path1+=".txt";

	
		 ofstream mod;
		 mod.open(path1);
	
		  for(int j=0;j<5;j++)
		  {
			 mod<<updatedPi[j]<<" ";
		  }
		  mod<<"\n";
	
		  for(int i=0;i<5;i++)
		  {
			 for(int j=0;j<5;j++)
			 {
				mod<<updatedA[i][j]<<" ";
			 }
			 mod<<endl;
		  }

		  for(int i=0;i<5;i++)
		  {
			 for(int j=0;j<32;j++)
			 { 
				 mod<<updatedB[i][j]<<" ";
			 }
			 mod<<endl;
		  }
	}

}



	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// button1
			// 
			resources->ApplyResources(this->button1, L"button1");
			this->button1->Name = L"button1";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// label1
			// 
			resources->ApplyResources(this->label1, L"label1");
			this->label1->ForeColor = System::Drawing::Color::Cornsilk;
			this->label1->Name = L"label1";
			this->label1->Click += gcnew System::EventHandler(this, &MyForm::label1_Click);
			// 
			// label2
			// 
			resources->ApplyResources(this->label2, L"label2");
			this->label2->ForeColor = System::Drawing::Color::Cornsilk;
			this->label2->Name = L"label2";
			this->label2->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label3
			// 
			resources->ApplyResources(this->label3, L"label3");
			this->label3->ForeColor = System::Drawing::Color::Cornsilk;
			this->label3->Name = L"label3";
			this->label3->Click += gcnew System::EventHandler(this, &MyForm::label3_Click);
			// 
			// button2
			// 
			resources->ApplyResources(this->button2, L"button2");
			this->button2->Name = L"button2";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// button3
			// 
			resources->ApplyResources(this->button3, L"button3");
			this->button3->Name = L"button3";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::button3_Click);
			// 
			// MyForm
			// 
			resources->ApplyResources(this, L"$this");
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ControlDarkDark;
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button1);
			this->Name = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
          //  label1->Text="U clicked RL";
			  //   MessageBox::Show("Start Recording");
			 
		         system("Recording_Module.exe 2 input_file.wav input_file.txt");
				 //Console::WriteLine("Recorded");
			 long double r[13],c[13],a[13];

			ifstream f;
			f.open("input_file.txt");
			
			if(f.fail())
			{
				cout<<"Unable to open the file";
			}

			vector<long double> data;
			long double temp;
			string str;

			for(int y=0;y<5;y++)
			{
				getline(f,str);
			}

			while(f>>temp)
			{
				data.push_back(temp);
			}

			int s=getMax(data);

			//cout<<s<<" ";
			if(s<3000)
			{
				cout<<"Record Again\n";
				int e;
				cin>>e;
				return ;
			}
			ofstream test;
			test.open("testing1.txt");
			test.close();


			for(int k=40;k>0;k--)
			{
			  durbin1(data,s-k*80,r,a,c);
			}
			//cout<<"Here1";
			for(int k=0;k<45;k++)
			{
			  durbin1(data,s+k*80,r,a,c);
			}
			//cout<<"durbin\n ";

		  vector<vector <long double>> codebook,obs;

		  codebook.resize(32);
		  obs.resize(60);

		  vector <long double> book,univ;
		  ifstream cb,uni;
		  long double data1;

		  cb.open("codebook1.txt");
		  uni.open("testing1.txt"); 
			
		    if(cb.fail())
			     cout<<"Unable to open the file";

					while(cb>>data1)
						{
							book.push_back(data1);
						}

			if(uni.fail())
			     cout<<"Unable to open the file";

					while(uni>>data1)
					{
						univ.push_back(data1);
					}


			for(int i=0;i<32;i++)
			{
				for(int j=0;j<12;j++)
				{
					codebook[i].push_back(book[i*12+j]);
				}
			}
			


			vector<long double> observation_sequence[85];
			vector<long double> observation;

			for(int j=0;j<85;j++)
			{
				for(int m=0;m<12;m++)
     				observation_sequence[j].push_back(univ[j*12+m]);
			}
	
			for(int j=0;j<85;j++)
			{
				int seq=compute_Observation_Sequence(codebook,observation_sequence[j]);
				observation.push_back(seq);
			}
		
			int prediction=digitRecognizer(observation);
			
			cout<<"Language is: "<<lang[prediction]<<endl;
			
			//ofstream test;
			test.open("testing1.txt");
			test.close();
			f.close();
			
			if(prediction==0)
			   {
				PlaySound(TEXT("0.wav"),NULL,SND_SYNC);
				this->Hide();
				newForm1^ f2 =gcnew newForm1();
				f2->Text="Hindi Playlist";
				f2->ShowDialog();
				//this->Show();
		     	}

        	if(prediction==1)
			   {
				PlaySound(TEXT("1.wav"),NULL,SND_SYNC);

				this->Hide();
				newForm2^ f3 =gcnew newForm2();
		  		f3->Text="English Playlist";
				f3->ShowDialog();
					//			this->Show();
			}

				if(prediction==2)
			   {
				PlaySound(TEXT("2.wav"),NULL,SND_SYNC);
			    

			    this->Hide();
				newForm3^ f4 =gcnew newForm3();
				f4->Text="Marathi Playlist";
				f4->ShowDialog();
						//		this->Show();
				}
			

			
			

			 }
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void label3_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
		 Application::Exit();
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
		    	 this->Hide();
				newForm4^ f5 =gcnew newForm4();
				f5->Text="Live Training";
				f5->ShowDialog();
		 }
};
}
//#endif

