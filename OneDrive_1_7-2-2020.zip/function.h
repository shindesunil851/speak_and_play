#include <iomanip>
#include <sstream>
#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include <stdlib.h>
#include<math.h>
#include <algorithm> 

using namespace std;


#ifndef FUNCTION_H
#define FUNCTION_H


void ff();
void normalization(vector<long double> &a,int s);
void DC_Shift(vector<long double> &a,int s);
void HammingWindow(vector<long double> &a,int s);
long double getDistance(long double cep[],vector <long double> arr);
long double ZCR(vector<long double> &a,int s,int e);
long double STE(vector<long double>&a,int s,int e);
int FindCluster(vector<vector<long double>> &val,vector<long double> &sm,int m);
void getCentroid(vector<long double> &result,vector<long double> &prev);
void addVector(vector<long double>&result,vector<long double>&sum);
void lbg(vector<vector<long double>>&universe,vector<vector<long double>>&val,int m1);
void computeAvg(vector<vector<long double>>&smp,vector<long double>&codeBook );
void splitCluster(vector<vector<long double>>&codeBook,int m);
int maximum(vector<long double> &a);

int getMax(vector<long double>&arr);

int compute_Observation_Sequence(vector<vector<long double>>codebook,vector<long double>observation_universe);
 void durbin(vector<long double>&arr,int s,long double *r,long double *ai,long double *c);
  void durbin1(vector<long double>&arr,int s,long double *r,long double *ai,long double *c);

long double power(long double x,long double p);
void alpha_Initialization(int observation[85],long double alpha[85][5],long double pi[5],long double B[5][32]);

void alpha_Induction(int observation[85],long double alpha[85][5],long double A[5][5],long double B[5][32]);

long double termination(long double alpha[85][5]);

void sigma_Compute(int observation[85],long double alpha[85][5],long double beta[85][5],long double A[5][5],long double B[5][32],long double p,long double sigma[84][5][5]);

void gamma_Compute(long double sigma[84][5][5],long double alpha[85][5],long double p,long double gamma[85][5]);
void beta_Initialization(long double beta[85][5]);
void beta_Induction(int observation[85],long double beta[85][5],long double A[5][5],long double B[5][32]);
void beta_final(long double beta[85][5]);
void delta_Initialization(int observation[85],long double delta[85][5],int psi[85][5],long double pi[5],long double B[5][32]);
void delta_Recursion(int observation[85],long double delta[85][5],int psi[85][5],long double A[5][5],long double B[5][32]);
void delta_Terminate(long double delta[85][5],int psi[85][5],int q[85]);
void StateSequence(int q[85]);
void updateA(long double sigma[84][5][5],long double gamma[85][5],long double updatedA[5][5]);
void updateB(int observation[85],long double gamma[85][5],long double B[5][32],long double updatedB[5][32]);
void updatePi(long double gamma[85][5],long double updatedPi[84]);
int digitRecognizer(vector<long double> &obs,int i);
void update1Model(string s);
void createNewmodel(int start);
void hmm(vector<long double> &obs,int start,int end);













#endif