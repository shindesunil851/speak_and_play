﻿#include "MyForm.h"
#include<stdio.h>
#include<iostream>

using namespace std;
using namespace System;
using namespace System::Windows::Forms;





int static main()
//int main (array＜String^＞^args )
{
 Application::EnableVisualStyles();
 Application::SetCompatibleTextRenderingDefault(false);
 guicpp::MyForm form;
 form.Text="Playlist";
// printf("hello\n");
  //system("Recording_Module.exe 2 input_file.wav input_file.txt");



 
   // Size the form to be 300 pixels in height and width.
  /// form.Size = new Size(300,300);
   // Display the form in the center of the screen.
  // form.StartPosition = FormStartPosition.CenterScreen;

// form->Location = Point(100, 100);

 Application::Run(%form);
// printf("hello\n");
 int x;
 //cin>>x;

 return 0;
}